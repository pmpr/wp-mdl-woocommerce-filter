<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6801065fecb67             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Traits; use Pmpr\Module\WoocommerceFilter\Helper; use Pmpr\Module\WoocommerceFilter\Setting; use Pmpr\Module\WoocommerceFilter\WoocommerceFilter; trait CommonTrait { public function kokwyquiqyoaaioc() : Helper { return Helper::symcgieuakksimmu(); } public function qeomwskywaguqyyu() : bool { return $this->weysguygiseoukqw(Setting::ykqqgqskiygugscu, false); } public function mqmocoguqcyymgqu() : ?array { return $this->caokeucsksukesyo()->aqasygcsqysmmyke()->mqmocoguqcyymgqu(); } public function wwqoiqcoccacyyyc() : bool { return $this->ocksiywmkyaqseou(WoocommerceFilter::geiygweugseyomyy . 'allow_add', $this->caokeucsksukesyo()->aqasygcsqysmmyke()->omuogooguicuqewu()); } }
