<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11f60f809             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Traits; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\WoocommerceFilter\Helper; use Pmpr\Module\WoocommerceFilter\Setting; use Pmpr\Module\WoocommerceFilter\WoocommerceFilter; use WP_Taxonomy; trait CommonTrait { public function kokwyquiqyoaaioc() : Helper { return Helper::symcgieuakksimmu(); } public function qeomwskywaguqyyu() : bool { return Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::ykqqgqskiygugscu, false); } public function mqmocoguqcyymgqu() : ?array { return $this->caokeucsksukesyo()->aqasygcsqysmmyke()->mqmocoguqcyymgqu(); } public function wwqoiqcoccacyyyc() : bool { return $this->ocksiywmkyaqseou(WoocommerceFilter::geiygweugseyomyy . "\141\154\154\157\167\137\x61\x64\144", $this->caokeucsksukesyo()->aqasygcsqysmmyke()->omuogooguicuqewu()); } }
