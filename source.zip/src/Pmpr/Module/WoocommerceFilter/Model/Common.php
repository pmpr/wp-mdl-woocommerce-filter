<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ecdf0a55e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Model; use Pmpr\Common\Foundation\ORM\DB\Model; abstract class Common extends Model { public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->myysgyqcumekoueo()->okgmqaeuaeymaocm($this->akuociswqmoigkas()); parent::ckgmycmaukqgkosk(); } }
