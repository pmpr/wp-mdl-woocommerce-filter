<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11f60f809             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Cache extends Common { public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->myysgyqcumekoueo()->yioesawwewqaigow(IconInterface::yiaicmmssocumqco)->guiaswksukmgageq(__("\103\141\x63\150\x65", PR__MDL__WOOCOMMERCE_FILTER))->muuwuqssqkaieqge(__("\x43\x61\x63\150\145\163", PR__MDL__WOOCOMMERCE_FILTER)); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(Constants::ciyoccqkiamemcmm)->acokiqqgsmoqaeyu()->gswweykyogmsyawy(__("\x56\x61\x6c\x75\x65", PR__MDL__WOOCOMMERCE_FILTER))); parent::ewaqwooqoqmcoomi(); } }
