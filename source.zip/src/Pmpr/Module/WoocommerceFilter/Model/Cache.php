<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66840138bbd28             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Cache extends Common { public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->myysgyqcumekoueo()->yioesawwewqaigow(IconInterface::yiaicmmssocumqco)->guiaswksukmgageq(__("\103\x61\x63\x68\145", PR__MDL__WOOCOMMERCE_FILTER))->muuwuqssqkaieqge(__("\103\141\143\x68\x65\163", PR__MDL__WOOCOMMERCE_FILTER)); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(self::ciyoccqkiamemcmm)->acokiqqgsmoqaeyu()->gswweykyogmsyawy(__("\126\141\x6c\x75\145", PR__MDL__WOOCOMMERCE_FILTER))); parent::ewaqwooqoqmcoomi(); } }
