<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6687087017e38             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Cache extends Common { public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->myysgyqcumekoueo()->yioesawwewqaigow(IconInterface::yiaicmmssocumqco)->guiaswksukmgageq(__("\103\141\143\x68\x65", PR__MDL__WOOCOMMERCE_FILTER))->muuwuqssqkaieqge(__("\x43\x61\143\150\x65\x73", PR__MDL__WOOCOMMERCE_FILTER)); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(self::ciyoccqkiamemcmm)->acokiqqgsmoqaeyu()->gswweykyogmsyawy(__("\126\141\154\x75\x65", PR__MDL__WOOCOMMERCE_FILTER))); parent::ewaqwooqoqmcoomi(); } }
