<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e426c3f8f0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Cache extends Common { public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->myysgyqcumekoueo()->yioesawwewqaigow(IconInterface::yiaicmmssocumqco)->guiaswksukmgageq(__("\103\x61\143\150\x65", PR__MDL__WOOCOMMERCE_FILTER))->muuwuqssqkaieqge(__("\x43\141\x63\x68\145\163", PR__MDL__WOOCOMMERCE_FILTER)); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(self::ciyoccqkiamemcmm)->acokiqqgsmoqaeyu()->gswweykyogmsyawy(__("\126\x61\x6c\x75\x65", PR__MDL__WOOCOMMERCE_FILTER))); parent::ewaqwooqoqmcoomi(); } }
