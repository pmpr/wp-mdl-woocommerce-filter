<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dabb67f056             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Model; use Pmpr\Module\WoocommerceFilter\Container; class Model extends Container { public function mameiwsayuyquoeq() { Cache::symcgieuakksimmu(); } }
