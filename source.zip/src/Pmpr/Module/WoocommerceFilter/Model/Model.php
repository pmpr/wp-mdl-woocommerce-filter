<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66840138bbd28             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Model; use Pmpr\Module\WoocommerceFilter\Container; class Model extends Container { public function mameiwsayuyquoeq() { Cache::symcgieuakksimmu(); } }
