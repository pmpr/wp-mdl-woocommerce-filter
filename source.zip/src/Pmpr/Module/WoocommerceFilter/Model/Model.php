<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6687087017e38             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Model; use Pmpr\Module\WoocommerceFilter\Container; class Model extends Container { public function mameiwsayuyquoeq() { Cache::symcgieuakksimmu(); } }
