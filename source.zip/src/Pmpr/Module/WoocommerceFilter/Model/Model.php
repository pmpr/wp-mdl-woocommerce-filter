<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8db16577             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Model; use Pmpr\Module\WoocommerceFilter\Container; class Model extends Container { public function mameiwsayuyquoeq() { Cache::symcgieuakksimmu(); } }
