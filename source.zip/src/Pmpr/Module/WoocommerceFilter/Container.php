<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6801065fecb67             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\WoocommerceFilter\Traits\CommonTrait; abstract class Container extends BaseClass { use CommonTrait; }
