<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8db16577             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Frontend; use Pmpr\Common\Foundation\Widget as BaseClass; class Widget extends BaseClass { }
