<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e426c3f8f0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Frontend; use Pmpr\Common\Foundation\Widget as BaseClass; class Widget extends BaseClass { }
