<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606b40897938             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Frontend; use Pmpr\Common\Foundation\Widget as BaseClass; class Widget extends BaseClass { }
