<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67e934c859e59             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Frontend; use Pmpr\Module\WoocommerceFilter\WoocommerceFilter; class Frontend extends Common { public function mameiwsayuyquoeq() { Sidebar::symcgieuakksimmu(); if ($this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq(WoocommerceFilter::geiygweugseyomyy)) { Ajax::symcgieuakksimmu(); } } }
