<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b70a9c8a8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Frontend; class Frontend extends Common { public function mameiwsayuyquoeq() { Sidebar::symcgieuakksimmu(); } }
