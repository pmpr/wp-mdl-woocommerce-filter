<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e426c3f8f0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Frontend; class Frontend extends Common { public function mameiwsayuyquoeq() { Sidebar::symcgieuakksimmu(); } }
