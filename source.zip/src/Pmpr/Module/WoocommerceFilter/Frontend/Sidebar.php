<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae9614a036             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Frontend; class Sidebar extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x77\x6f\157\143\157\x6d\x6d\x65\x72\x63\145\137\x73\x69\x64\145\x62\x61\x72", [$this, "\x72\x65\156\x64\x65\x72"], 50); } public function render() { if (!($this->wwqoiqcoccacyyyc() && $this->caokeucsksukesyo()->aqasygcsqysmmyke()->omuogooguicuqewu())) { goto mwysseaekcsiesmm; } $this->skqqcuwuuumqkykk(); mwysseaekcsiesmm: } }
