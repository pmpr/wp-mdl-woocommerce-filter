<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ecdf0a55e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Frontend; class Sidebar extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x77\157\157\143\x6f\x6d\x6d\x65\x72\143\x65\x5f\x73\x69\144\x65\x62\x61\x72", [$this, "\x72\145\156\144\145\x72"], 50); } public function render() { if (!($this->wwqoiqcoccacyyyc() && $this->caokeucsksukesyo()->aqasygcsqysmmyke()->omuogooguicuqewu())) { goto mwysseaekcsiesmm; } $this->skqqcuwuuumqkykk(); mwysseaekcsiesmm: } }
