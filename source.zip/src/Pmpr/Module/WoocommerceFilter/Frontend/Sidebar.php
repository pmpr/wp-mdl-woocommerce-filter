<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e426c3f8f0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Frontend; class Sidebar extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\x6f\157\143\x6f\x6d\155\x65\162\143\x65\x5f\x73\x69\x64\x65\142\x61\162", [$this, "\162\x65\x6e\x64\145\x72"], 50); } public function render() { if (!($this->wwqoiqcoccacyyyc() && $this->caokeucsksukesyo()->aqasygcsqysmmyke()->omuogooguicuqewu())) { goto cecuyayqoioasumi; } $this->skqqcuwuuumqkykk(); cecuyayqoioasumi: } }
