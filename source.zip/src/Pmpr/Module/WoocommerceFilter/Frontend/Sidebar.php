<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606b40897938             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Frontend; class Sidebar extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\x6f\x6f\143\x6f\155\x6d\145\162\143\145\x5f\x73\x69\x64\x65\x62\x61\162", [$this, "\162\x65\156\x64\x65\162"], 50); } public function render() { if (!($this->wwqoiqcoccacyyyc() && $this->caokeucsksukesyo()->aqasygcsqysmmyke()->omuogooguicuqewu())) { goto yiwiqaqmwiogawym; } $this->skqqcuwuuumqkykk(); yiwiqaqmwiogawym: } }
