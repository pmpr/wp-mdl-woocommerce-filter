<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8db16577             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Frontend; class Sidebar extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\x6f\157\x63\x6f\x6d\x6d\145\x72\x63\x65\137\163\151\x64\145\x62\141\x72", [$this, "\x72\145\156\144\x65\x72"], 50); } public function render() { if (!($this->wwqoiqcoccacyyyc() && $this->caokeucsksukesyo()->aqasygcsqysmmyke()->omuogooguicuqewu())) { goto eegqyykygiccaoeo; } $this->skqqcuwuuumqkykk(); eegqyykygiccaoeo: } }
