<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11f60f809             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Frontend; class Sidebar extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\157\x6f\x63\157\x6d\x6d\x65\162\143\x65\x5f\163\151\x64\145\142\141\x72", [$this, "\162\x65\x6e\x64\x65\162"], 50); } public function render() { if (!($this->wwqoiqcoccacyyyc() && $this->caokeucsksukesyo()->aqasygcsqysmmyke()->omuogooguicuqewu())) { goto wcesymwqykqoyuqk; } $this->skqqcuwuuumqkykk(); wcesymwqykqoyuqk: } }
