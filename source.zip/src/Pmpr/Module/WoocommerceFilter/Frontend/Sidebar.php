<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66840138bbd28             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Frontend; class Sidebar extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\157\x6f\x63\x6f\155\155\x65\x72\x63\x65\x5f\x73\x69\144\x65\142\141\162", [$this, "\162\145\x6e\144\x65\162"], 50); } public function render() { if (!($this->wwqoiqcoccacyyyc() && $this->caokeucsksukesyo()->aqasygcsqysmmyke()->omuogooguicuqewu())) { goto wusciwkkckmqigms; } $this->skqqcuwuuumqkykk(); wusciwkkckmqigms: } }
